function goTo(page) {
  window.location.href = page;
}
