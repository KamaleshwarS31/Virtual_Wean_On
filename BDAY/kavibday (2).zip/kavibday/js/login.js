function login() {
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  // SET YOUR SECRET ANSWERS HERE
  // Example: name in mixed case + nickname you use
  const correctUsername = "SKAVISRI";      // change this
  const correctPassword = "Kavisss";    // change this

  if (username === correctUsername && password === correctPassword) {
    window.location.href = "home.html";
  } else {
    document.getElementById("error").innerText =
      "❌ Oops… think about how WE say it 😉";
  }
}
